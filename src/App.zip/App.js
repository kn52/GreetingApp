import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <div id="container">
          <button>ADD GREETING</button> 
          <form class="table_Container animate">
          <table>
            <tr>
              <th>Content</th>
              <th><a href="">Edit</a></th>
              <th><a href="">Delete</a></th>
            </tr>
          </table>
          </form>
        </div>
      </header>
    </div>
  );
}

export default App;
